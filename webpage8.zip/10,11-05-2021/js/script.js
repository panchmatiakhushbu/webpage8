/*Right Side-bar Header js start*/
function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

/*Right Side-bar Header js end*/

/*Slider js start*/
$(document).ready(function(){
  
  $(".Modern-Slider").slick({
    autoplay:true,
    autoplaySpeed:10000,
    speed:600,
    slidesToShow:1,
    slidesToScroll:1,
    pauseOnHover:false,
    dots:true,
    pauseOnDotsHover:true,
    cssEase:'linear',
   // fade:true,
    draggable:false,
    prevArrow:'<button class="PrevArrow"></button>',
    nextArrow:'<button class="NextArrow"></button>', 
  });
  
})
/*Slider js end*/

/*ourexpertnesses js start*/

  $('.autoplay-slider').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 4000, 
    speed: 800,
    prevArrow: false,
    nextArrow:false,
    dots: false, 
    responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    }    
  ]
});

/*ourexpertnesses js end*/


/*client-logo slider js start*/

   $('.multiple-item').slick({
      autoplaySpeed: 4000, 
      speed: 800,
      autoplay:true,
      slidesToShow: 4, 
      slidesToScroll: 1,
      dots: false,
      arrows:false,
      responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    }    
  ]
  });


/*client-logo slider js end*/

/*ourprojects-item slider js start*/

   $('.ourprojects-item').slick({
      autoplaySpeed: 4000, 
      speed: 800,
      autoplay:true,
      slidesToShow: 4, 
      slidesToScroll: 1,
      dots: false,
      arrows:false,
      responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    }    
  ]
  });

/*ourprojects-item slider js end*/

/*ourteam js start*/

  $('.our-team-slider').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 4000, 
    speed: 800,
    prevArrow: false,
    nextArrow:false,
    dots: false, 
    responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows:false,
        autoplay: true,
      }
    }    
  ]
});

/*ourteam js end*/

/*Animation js start*/

// new WOW().init();

$(window).on("load scroll", function () {
  "use strict";
  $(".wow").css("animation-play-state", "paused");
  $(".wow").each(function () {
    if (!($(this).data("wow-duration"))) {
      $(this).data("wow-duration", "1s");
    }
    if ($(this).data("wow-offset") + $(this).offset().top <= $(window).scrollTop() + $(window).height() || (!($(this).data("wow-offset")) && $(this).offset().top <= $(window).scrollTop() + $(window).height())) {
      $(this).css("animation-play-state", "running ");
      $(this).css({
        "animationDuration": $(this).data("wow-duration"),
        "animationDelay": $(this).data("wow-delay"),
        "animationIterationCount": $(this).data("wow-iteration")
      });
    }
  });
});
/*Animation js end*/

